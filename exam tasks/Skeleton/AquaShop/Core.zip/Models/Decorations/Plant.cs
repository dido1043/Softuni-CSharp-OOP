﻿

namespace AquaShop.Models.Decorations
{
    using System;
    using System.Collections.Generic;
    using System.Text;
    public class Plant : Decoration
    {
        public Plant() : base(5, 10)
        {
        }
    }
}
