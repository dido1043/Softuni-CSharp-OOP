﻿namespace AquaShop.Models.Decorations
{
    using System;
    using System.Collections.Generic;
    using System.Text;

    public class Ornament : Decoration
    {
        //Potential bug
        public Ornament() : base(1, 5)
        {

        }
    }
}
