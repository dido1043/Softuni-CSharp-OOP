﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BookingApp.Models.Rooms.Entities
{
    public class DoubleBed : Room
    {
        public DoubleBed() : base(2)
        {
        }
    }
}
