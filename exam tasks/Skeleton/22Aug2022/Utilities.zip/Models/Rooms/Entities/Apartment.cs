﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BookingApp.Models.Rooms.Entities
{
    public class Apartment : Room
    {
        public Apartment() : base(6)
        {
        }
    }
}
