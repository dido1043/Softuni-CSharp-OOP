﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BookingApp.Models.Rooms.Entities
{
    public class Studio : Room
    {
        public Studio() : base(4)
        {
        }
    }
}
