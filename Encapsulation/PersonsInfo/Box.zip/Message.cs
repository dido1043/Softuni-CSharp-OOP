﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ClassBoxData
{
    public class Message
    {
        public const string Error = "{0} cannot be zero or negative.";
    }
}
